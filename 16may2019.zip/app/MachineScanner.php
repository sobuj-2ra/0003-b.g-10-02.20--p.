<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MachineScanner extends Model
{
    protected $guarded = [];
}

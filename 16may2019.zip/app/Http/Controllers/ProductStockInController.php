<?php

namespace App\Http\Controllers;

use App\Barcode;
use App\ProductStockIn;
use Illuminate\Http\Request;

class ProductStockInController extends Controller
{
    
    public function add(Request $request)
    {
    	$json_response = [];
    	

    	if ($request->has(['barcode', 'scanner_id'])) {
            $check_if_produced = Barcode::where('barcode',$request->barcode)->count(); //0 means not produced yet, 1 means produced but not stocked in

            if ($check_if_produced == 0) {
            	$check_if_already_stockin = ProductStockIn::where('barcode',$request->barcode)->count();

            	if ($check_if_already_stockin == 0) {
            		$json_response['Code_status'] = 0;//not produced yet
            	}elseif($check_if_already_stockin == 1){
            		$json_response['Code_status'] = 2;// produced and stocked in
            	}else{
            		$json_response['Code_status'] = 3; //code has been scanned two times
            	}
            }elseif($check_if_produced == 1){ //produced but not stocked in

            	$old_data = Barcode::where('barcode',$request->barcode)->first();

            	$new_data                 = $old_data->attributesToArray();
                $new_data['scanner_id']   = $request->scanner_id;
            	$new_data['is_delivered'] = 0;

            	// remove attributes
            	$new_data = array_except($new_data, ['id','total_print','created_at','updated_at']);
            	// create new Stock in from cloned data
            	$cloned_data =  ProductStockIn::create($new_data);
            	//delete temp barcode record
            	$old_data->delete();
            	$json_response['Code_status'] = 1;
            }

            $total_box                  = ProductStockIn::all()->count();
    		$json_response['box_count'] = $total_box;
            return response()->json($json_response);
            
    	}

    	return 'Please input barcode and scanner_id';
    }



}

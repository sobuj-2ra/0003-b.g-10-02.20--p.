<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DailyShiftDetails extends Model
{
    protected $guarded = [];
}

<!DOCTYPE html>
<html>
<head>
	<title>Scanner</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/style.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	
</head>
<body>
<?php echo $__env->make('includes.buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="handheld">
	<div class="container pt-3 h-100">
		<div class="row">
			<div class="col-12">
				<div class="list-group">

					<?php if(count($scanners) > 0): ?>
						<?php $__currentLoopData = $scanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="<?php echo e(route('handheldAllData',$scanner->id)); ?>" class="list-group-item">Scanner Id: <?php echo e($scanner->device_id); ?></a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

				  
				  
				</div>
			</div>
		</div>
	</div>

</div>











<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/main.js')); ?>"></script>
<script type="text/javascript">
	// location.reload();
</script>

</body>
</html>	
<?php $__env->startSection('title','Item list'); ?>

<?php $__env->startSection('extra_css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>  
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="display: inline-block;">
        Item List
      </h1>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('item_add')): ?>
        <a href="<?php echo e(route('items.create')); ?>" class="btn btn-success pull-right ">Add New</a>
      <?php endif; ?>
    </section>

    <!-- Main content -->
    <section class="content">
      <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


       <div class="box">
         <div class="box-header">
           
         </div>
         <!-- /.box-header -->
         <div class="box-body">
           <table id="example1" class="table table-bordered table-striped table-responsive">
             <thead>
             <tr>
                <th>#</th>
                <th>Code</th>
                <th>Name</th>
                <th>Gr Name</th>
                <th>Gr Code</th>
                <th>Size</th>
                <th>Added By</th>
                <th>action</th>
              </tr>
             </thead>
             <tbody>
             <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->index +1); ?></td>
                  <td><?php echo e($single_item->item_code); ?></td>
                  <td><?php echo e($single_item->item_name); ?></td>
                  <td><?php echo e($single_item->group_name); ?></td>
                  <td><?php echo e($single_item->group_code); ?></td>
                  <td><?php echo e($single_item->pack_size); ?></td>
                  <td><?php echo e($single_item->getUser->name); ?></td>
                  <td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('item_edit')): ?>
                      <a href="<?php echo e(route('items.edit',$single_item->id)); ?>" class="btn btn-primary"><i class="fa fa-pencil"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('item_delete')): ?>
                      <a href="#" onclick="if(confirm('are you sure ?')){ event.preventDefault(); document.getElementById('delete-form-<?php echo e($single_item->id); ?>').submit();}else{event.preventDefault();}" class="btn btn-danger"><i class="fa fa-trash-o"></i></a>
                      <form id="delete-form-<?php echo e($single_item->id); ?>" action="<?php echo e(route('items.destroy',$single_item->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                      </form>
                    <?php endif; ?>

                  </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
             <tfoot>
             <tr>
              <tr>
                <th>#</th>
                <th>Code</th>
                <th>Name</th>
                <th>Gr Name</th>
                <th>Gr Code</th>
                <th>Size</th>
                <th>Added By</th>
                <th>action</th>
              </tr>
             </tr>
             </tfoot>
           </table>
         </div>
         <!-- /.box-body -->
       </div>
       <!-- /.box -->
    </section>
    <!-- /.content -->


   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_js'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('public/admin_asset/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/admin_asset/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
  <script type="text/javascript">
    $(function(){
      $('#example1').DataTable();


    })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
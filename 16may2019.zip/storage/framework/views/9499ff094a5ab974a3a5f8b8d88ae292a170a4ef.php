<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Login')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="employee_id" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Employee Id')); ?></label>

                            <div class="col-md-6">
                                <input id="employee_id" data-inputmask="'mask': '999.999'" data-mask type="text" class="form-control<?php echo e($errors->has('employee_id') ? ' is-invalid' : ''); ?>" name="employee_id" value="<?php echo e(old('employee_id')); ?>" required autofocus>

                                <?php if($errors->has('employee_id')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('employee_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- InputMask -->
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.numeric.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<script type="text/javascript">
    $('#employee_id').inputmask();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
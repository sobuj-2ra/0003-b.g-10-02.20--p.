<?php if(count($errors) > 0): ?>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<div class="alert alert-danger"><?php echo e($error); ?></div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if(session()->has('message')): ?>
	<div class="callout callout-success alert alert-success">
	  <h4>Message!</h4>
	  <?php echo e(session('message')); ?>

	</div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
	<div class="callout callout-success alert alert-success">
	  <h4>Success!</h4>
	  <?php echo e(session('success')); ?>

	</div>
<?php endif; ?>

<?php if(session()->has('danger')): ?>
	<div class="callout callout-danger alert alert-danger">
	  <h4>Error!</h4>
	  <?php echo e(session('danger')); ?>

	</div>
<?php endif; ?>
<?php if(session()->has('warning')): ?>
	<div class="callout callout-warning alert alert-warning">
	  <h4>Warning!</h4>
	  <?php echo e(session('warning')); ?>

	</div>
<?php endif; ?>
<?php if(session()->has('custom-error')): ?>
	<div class="">
	  <h4>Success!</h4>
	  <?php echo e(session('custom-error')); ?>

	</div>
<?php endif; ?>
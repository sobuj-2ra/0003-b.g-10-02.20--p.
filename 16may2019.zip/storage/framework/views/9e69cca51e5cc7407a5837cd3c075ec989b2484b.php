<?php $__env->startSection('title','Add Device'); ?>

<?php $__env->startSection('extra_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="display: inline-block;">
        Add Device
      </h1>
      <a href="<?php echo e(route('devices.index')); ?>" class="btn btn-success pull-right ">List</a>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- general form elements -->
      <div class="box box-success">
        <div class="box-header with-border">
          <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div id="form_output"></div>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" id="ajax_form" action="<?php echo e(route('devices.store')); ?>" method="POST" enctype="multipart/form-data">
          <div class="box-body">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
              <label for="device_name">Device Name</label>
              <input type="text" name="device_name" class="form-control" id="device_name" placeholder="Enter device Name" value="<?php echo e(old('device_name')); ?>" required="">
            </div>

            <div class="form-group">
              <label for="device_id">Device Code/ID</label>
              <input type="text" name="device_id" class="form-control" id="device_id" placeholder="Enter device Name" value="<?php echo e(old('device_id')); ?>" required="">
              <span id="deviceError" class="bg-danger"></span>
            </div>

            <div class="form-group">
              <label for="device_ip">Device Ip/Number</label>
              <input type="text" name="device_ip" class="form-control" id="device_ip" placeholder="Enter device Name" value="<?php echo e(old('device_ip')); ?>">
            </div>

            

            <div class="form-group">
              <label for="device_type">Device Type</label>
              <select name="device_type" class="form-control" required="">
              	<option value="">Select</option>
              	<option value="printer">printer</option>
              	<option value="scanner">scanner</option>
              </select>
            </div>

          </div>
          <!-- /.box-body -->

          <div class="box-footer">
            <button type="submit" id="add_data" class="btn btn-success">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.box -->

      

    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>
<!-- InputMask -->
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.numeric.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>

<script type="text/javascript">
	$(function(){
		//Datemask dd/mm/yyyy
		// $('[data-mask]').inputmask();

    $('#device_id').on('blur',function(){
      var device_id = $('#device_id').val();
      var _token = $('input[name="_token"]').val();

      //console.log(device_id,_token);
      $.ajax({
        url: "<?php echo e(route('checkDeviceId')); ?>",
        type: 'POST',
        dataType: 'json',
        data: {device_id:device_id,_token:_token},
        success: function(data){
          console.log(data);
          $('#deviceError').html(data.message);
        }
      });
    });




    
    
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Sidebar user panel -->
<div class="user-panel">
  <div class="pull-left image">
    <img src="<?php echo e(asset('public/storage/employees/'.Auth::user()->image)); ?>" class="img-circle" alt="User Image">
  </div>
  <div class="pull-left info">
    <p><?php echo e(Auth::user()->name); ?></p>
    <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
  </div>
</div>
<!-- search form -->
<form action="#" method="get" class="sidebar-form">
  <div class="input-group">
    <input type="text" name="q" class="form-control" placeholder="Search...">
    <span class="input-group-btn">
          <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
          </button>
        </span>
  </div>
</form>
<!-- /.search form -->
<!-- sidebar menu: : style can be found in sidebar.less -->
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>

  <li class="treeview">
      <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-circle-o text-red"></i> <span>Dashboard</span></a></li>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Employee</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-circle-o"></i>List</a></li>
      <li><a href="<?php echo e(route('users.create')); ?>"><i class="fa fa-circle-o"></i>Add</a></li>
    </ul>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Device</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('devices.index')); ?>"><i class="fa fa-circle-o"></i>List</a></li>
      <li><a href="<?php echo e(route('devices.create')); ?>"><i class="fa fa-circle-o"></i>Add</a></li>
    </ul>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Machine</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('machines.index')); ?>"><i class="fa fa-circle-o"></i>List</a></li>
      <li><a href="<?php echo e(route('machines.create')); ?>"><i class="fa fa-circle-o"></i>Add</a></li>
    </ul>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Shift</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('shifts.index')); ?>"><i class="fa fa-circle-o"></i>List</a></li>
      <li><a href="<?php echo e(route('shifts.create')); ?>"><i class="fa fa-circle-o"></i>Add</a></li>
    </ul>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Items</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('items.index')); ?>"><i class="fa fa-circle-o"></i>List</a></li>
      <li><a href="<?php echo e(route('items.create')); ?>"><i class="fa fa-circle-o"></i>Add</a></li>
    </ul>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>InvoiceInfo</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('invoiceinfo.index')); ?>"><i class="fa fa-circle-o"></i>List</a></li>
    </ul>
  </li>

  <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Orders</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="<?php echo e(route('allinvoice')); ?>"><i class="fa fa-circle-o"></i>By Customer</a></li>
      <li><a href="<?php echo e(route('allitem')); ?>"><i class="fa fa-circle-o"></i>By Item</a></li>
    </ul>
  </li>
  
    <li><a href="<?php echo e(route('activitylog.index')); ?>"><i class="fa fa-circle-o text-aqua"></i> <span>Logs</span></a></li>

</ul>
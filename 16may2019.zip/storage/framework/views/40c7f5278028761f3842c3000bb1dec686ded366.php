<!DOCTYPE html>
<html>
<head>
	<title>Daily Shift</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/fontawesome.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/sweetalert.css')); ?>">
 	<link rel="stylesheet" href="<?php echo e(asset('admin_asset/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/style.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
<?php echo $__env->make('includes.buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container pt-3">
	<form method="POST" action="<?php echo e(route('updateDailyShift',$current_shift->id)); ?>" id="DailyShiftForm">
		<div class="row">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>
			<div class="col-12">
				 <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div class="col-4">
				<label for="Shift" class="font-weight-bold">Shift</label>
				<select class="custom-select" name="shift" required="" id="Shift" disabled="">
					<?php if(count($shifts) > 0): ?>
				  		<option value="">Select Shift</option>
						  <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  	<option 
						  		value="<?php echo e($shift->shift_number); ?>"
						  		<?php echo e(($shift->shift_number == $current_shift->shift) ? 'selected' : ''); ?> 

						  	><?php echo e($shift->shift_number); ?> (<?php echo e($shift->shift_start); ?>-<?php echo e($shift->shift_end); ?>)</option>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<option>No Shift in database</option>
					<?php endif; ?>
				</select>

			</div>

			<div class="col-4">
				<label for="machine" class="font-weight-bold">Machine</label>
				<select class="custom-select" name="machine" required="" id="machine" disabled="">
					<?php if(count($machines) > 0): ?>
				  		<option value="">Select machine</option>
						  <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  	<option 
						  		value="<?php echo e($machine->number); ?>"
						  		<?php echo e(($machine->number == $current_shift->machine) ? 'selected' : ''); ?> 

						  	><?php echo e($machine->number); ?></option>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<option>No Machine in database</option>
					<?php endif; ?>
				</select>
				
				<input type="hidden" name="machine" value="<?php echo e($current_shift->machine); ?>">
			</div>

			<div class="col-4">
				<label for="production_date" class="font-weight-bold">Production Date:</label>
				<input type="text" name="production_date" class="form-control d-inline pull-right" id="datepicker" value="<?php echo e(\Carbon\Carbon::parse($current_shift->production_date)->toDateString()); ?>" >
			</div>

			<div class="col-6">
				<label for="item_group" class="font-weight-bold">Item_group</label>
				<select class="custom-select" name="item_group" required="" id="item_group">
					<?php if(count($items_group) > 0): ?>
				  		<option value="">Select item Group</option>
						  <?php $__currentLoopData = $items_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  	<option 
						  		value="<?php echo e($item->group_name); ?>"
								<?php echo e(($item->group_name == $current_shift->getitem->group_name) ? 'selected' : ''); ?> 
						  		><?php echo e($item->group_name); ?></option>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<option>No items</option>
					<?php endif; ?>
				</select>
			</div>

			<div class="col-6">
				<label for="item" class="font-weight-bold">Item</label>
				<select class="custom-select" name="item" required="" id="item">
				  		<option value="">Select item</option>
				</select>
			</div>
		</div>
		<div class="row mt-3">

			<div class="col-12 live__scroll">
				<h5>Current Watcher</h5>
				<div class="row no-gutters watcher-packer dragscroll" style="width: 100%; height: auto; overflow: scroll; cursor: grab; cursor : -o-grab; cursor : -moz-grab; cursor : -webkit-grab;">
					<?php $__currentLoopData = $current_shift->workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current_watcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($current_watcher->group == 'watcher'): ?>
							<div class="col-2 live__scroll--box nopad">
								<label class="image-checkbox image-checkbox-checked">
								    <img class="img-responsive d-block" src="<?php echo e(asset('/storage/employees/'.$current_watcher->image)); ?>" alt="<?php echo e($current_watcher->name); ?>" height="100px" width="auto">
								    <input type="checkbox" checked="" name="watcher[]" value="<?php echo e($current_watcher->id); ?>" class="" >
								    <i class="fa fa-check hidden d-none"></i>
								    <span class="badge badge-danger"><?php echo e($current_watcher->name); ?></span>
								</label>
							</div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

			<div class="col-12 live__scroll">
				<h5>Additional Watcher</h5>
				<div class="row no-gutters watcher-packer dragscroll" style="width: 100%; height: auto; overflow: scroll; cursor: grab; cursor : -o-grab; cursor : -moz-grab; cursor : -webkit-grab;">
					<?php $__currentLoopData = $watchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $watcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-2 live__scroll--box nopad">
							<label class="image-checkbox">
							    <img class="img-responsive d-block" src="<?php echo e(asset('/storage/employees/'.$watcher->image)); ?>" alt="<?php echo e($watcher->name); ?>" height="100px" width="auto">
							    <input type="checkbox" name="watcher[]" value="<?php echo e($watcher->id); ?>" class="" >
							    <i class="fa fa-check hidden d-none"></i>
							    <span class="badge badge-danger"><?php echo e($watcher->name); ?></span>
							</label>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

			<div class="col-12 live__scroll">
				<h5>Current Packer</h5>
				<div class="row no-gutters watcher-packer dragscroll" style="width: 100%; height: auto; overflow: scroll; cursor: grab; cursor : -o-grab; cursor : -moz-grab; cursor : -webkit-grab;">
					<?php $__currentLoopData = $current_shift->workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current_packer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($current_packer->group == 'packer'): ?>
							<div class="col-2 live__scroll--box nopad">
								<label class="image-checkbox">
								    <img class="img-responsive d-block" src="<?php echo e(asset('/storage/employees/'.$current_packer->image)); ?>" alt="<?php echo e($current_packer->name); ?>" height="100px" width="auto">
								    <input type="checkbox" checked="" name="packer[]" value="<?php echo e($current_packer->id); ?>" class="">
								    <i class="fa fa-check hidden d-none"></i>
								    <span class="badge badge-danger"><?php echo e($current_packer->name); ?></span>
								</label>
							</div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

			<div class="col-12 live__scroll">
				<h5>Additional Packer</h5>
				<div class="row no-gutters watcher-packer dragscroll" style="width: 100%; height: auto; overflow: scroll; cursor: grab; cursor : -o-grab; cursor : -moz-grab; cursor : -webkit-grab;">
					<?php $__currentLoopData = $packers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-2 live__scroll--box nopad">
							<label class="image-checkbox">
							    <img class="img-responsive d-block" src="<?php echo e(asset('/storage/employees/'.$packer->image)); ?>" alt="<?php echo e($packer->name); ?>" height="100px" width="auto">
							    <input type="checkbox" name="packer[]" value="<?php echo e($packer->id); ?>" class="">
							    <i class="fa fa-check hidden d-none"></i>
							    <span class="badge badge-danger"><?php echo e($packer->name); ?></span>
							</label>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

			<div class="col-12 mb-5">
				<button type="submit" class="btn btn-success" id="ButtonConfirm">Submit</button>
				<a href="<?php echo e(route('singlemachine',$current_shift->machine)); ?>" class="btn btn-danger allreset">Cancel</a>
			</div>

		</div>
	</form>
</div>



<script type="text/javascript" src="<?php echo e(asset('front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/asvd/dragscroll/master/dragscroll.js"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/main.js')); ?>"></script>
<script type="text/javascript">

	$('#datepicker').datepicker({
	  autoclose: true,
	  format:'yyyy-mm-dd',
	})
	// image gallery
    // init the state from the input
    $(".image-checkbox").each(function () {
        if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
            $(this).addClass('image-checkbox-checked');
        } else {
            $(this).removeClass('image-checkbox-checked');
        }
    });

    // sync the state to the input
    $(".image-checkbox").on("click", function (e) {
        $(this).toggleClass('image-checkbox-checked');
        var $checkbox = $(this).find('input[type="checkbox"]');
        $checkbox.prop("checked", !$checkbox.prop("checked"))

        e.preventDefault();
    });
    function checkIfallChecked(){
    	// console.log($('input[name="packer[]"]:checked').length);
    	console.log($('option:selected').length);
        if ( ($('input[name="watcher[]"]:checked').length >= 1) && ($('input[name="packer[]"]:checked').length >= 1) && ($('option:selected').length == 4))
        {

            return true;
        }else{
        	return false;
        }
    }


    $("#ButtonConfirm").on("click",function(e){
    	e.preventDefault();
    	if(checkIfallChecked()){
    		swal({
    		  title: "Are you sure !!",
    		  text: "old info of this machine will be replaced",
    		  type: "info",
    		  showCancelButton: true,
    		  closeOnConfirm: false,
    		  showLoaderOnConfirm: true
    		},

    		function(isConfirm){
    		  if (isConfirm){
    		  	$("#DailyShiftForm").submit();
    		  } else {
    		    swal("Cancelled", "Cancelled suucessfuly :)", "error");
    		  }
    		});
    	}else{
    		swal("Please select all the fields");
    	}
		
    });

        $("#item_group").on('change',function(){
        	var item_group = $(this).find(':selected').val();
        	var _token = $('meta[name="csrf-token"]').attr('content');
        	console.log(item_group,_token);

        	$.ajax({
        		url: '<?php echo e(route('getItemByGrName')); ?>',
        		type: 'POST',
        		dataType: 'json',
        		data: {item_group:item_group,_token:_token },
        		success: function(data){
        			// console.log(data);
        			 var items = `<option value="">Select Item</option>`;
        			 $.each(data, function(index, item) {
        			    items += `<option value='${item.item_code}'>${item.item_code} (${item.item_name})</option>`;
        			 });
        			 $('#item').html(items);
        		},
    	    	error: function (xhr, ajaxOptions, thrownError) {
    	    		console.log(thrownError);
    	    		swal("Error!", "There was an error", "error");
                }
        	});
        });

        function changeItem(){
             var item_group = $('#item_group').find(':selected').val();
             var _token = $('meta[name="csrf-token"]').attr('content');

             $.ajax({
                url: '<?php echo e(route('getItemByGrName')); ?>',
                type: 'POST',
        		dataType: 'json',
        		data: {item_group:item_group,_token:_token },
                success: function(data){
        			// console.log(data);
        			 var items = `<option value="">Select Item</option>`;
        			 $.each(data, function(index, item) {
		              items += "<option value="+ item.item_code +" "+ matchData(item.item_code, <?php echo e($current_shift->item); ?>)   +">"+ item.item_code +" ("+item.item_name+")</option>";
		           });
        			 $('#item').html(items);
        		},
    	    	 error: function (xhr, ajaxOptions, thrownError) {
    	    		console.log(thrownError);
    	    		swal("Error!", "There was an error", "error");
                }
             });
           }

        changeItem();

        function matchData(data1,data2){
          if(data1 != data2){
            return '';
          }else{
            return ' selected ';
          }
        }


    //# sourceURL=pen.js
</script>
</body>
</html>	
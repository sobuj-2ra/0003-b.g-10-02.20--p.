<html>
<head>
	<title><?php echo e($machine->number); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/sweetalert.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/style.css')); ?>">
 	<link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<!-- Scripts -->
	<script src="<?php echo e(asset('public/js/app.js')); ?>"></script>
</head>
<body>





<div class="container pt-3 h-100" id="SingleMachine">
	<?php $__env->startSection('single_machine_edit'); ?>
		<?php if($worker_data != NULL && count($worker_data->workers) > 0): ?>
			<a href="<?php echo e(route('dailyshiftEdit',$machine->number)); ?>" class="btn btn-danger">Edit Details</a>
		<?php endif; ?>
	<?php $__env->stopSection(); ?>

	<div class="row">
		<div class="col-sm-10">
			<?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="row d-flex ">
				
				<div class="col-2">
					Shift: <span id="shift">{{ shift || shiftPlaceHolde }}</span>
				</div>
				<div class="col-2">
					<?php echo e($machine->name); ?>(<span id="machineNUmber"><?php echo e($machine->number); ?></span>)
				</div>
				<div class="col-3">
					Item:<span>{{ item || itemPlaceHolde }}</span>
				</div>

				<div class="col-5">
					Production Date:
					<input type="text" name="production_date" class="form-control d-inline pull-right" id="datepicker" value="<?php echo e(($worker_data != null) ? \Carbon\Carbon::parse($worker_data->production_date)->toDateString() : "Not assaigned"); ?>">

				</div>

				<div class="col-12">
					<h4 class="text-muted">Grade</h4>
				</div>
				<div class="col-12">
					<div class="toggle">
						<input type="radio" name="grade" value="A" id="A" />
						<label for="A">A</label>
						<input type="radio" name="grade" value="B" id="B" />
						<label for="B">B</label>
						<input type="radio" name="grade" value="C" id="C" />
						<label for="C">C</label>
					</div>
				</div>




				<div class="col-12">
					<h4 class="text-muted">Packers</h4>
				</div>
				
				
				<div class="col-12">
					<div class="row">
						<div class="toggle">
							<span v-for="(single_worker,index) in workers" v-if="single_worker.group == 'packer'">
								<input type="radio"  v-if="single_worker.group == 'packer'" name="packer" :value="single_worker.employee_id" :id="single_worker.employee_id" />
								<label v-if="single_worker.group == 'packer'" :for="single_worker.employee_id">
									<img :src="single_worker.image" :alt="single_worker.employee_id" height="100" width="100" class=" d-block">
									{{ single_worker.name }}
								</label>
							</span>
						</div>
					</div>
				</div>

				<div class="col-12">
					<h4 class="text-muted">Watcher</h4>
				</div>

				<div class="col-12">
					<div class="row">
						<div class="toggle">
							<span v-for="(single_worker,index) in workers" v-if="single_worker.group == 'watcher'">
								<input type="radio"  v-if="single_worker.group == 'watcher'" name="watcher" :value="single_worker.employee_id" :id="single_worker.employee_id" />
								<label v-if="single_worker.group == 'watcher'" :for="single_worker.employee_id">
									<img :src="single_worker.image" :alt="single_worker.employee_id" height="100" width="100" class=" d-block">
									{{ single_worker.name }}
								</label>
							</span>
						</div>
					</div>
				</div>

				<div class="col-12">
					<h4 v-if="Object.keys(workers).length === 0" class="text-white lead p-2 badge-info">Watcher/Packer Not Assigned</h4>
				</div>


				<div class="col-12">
					<h4 class="text-muted">Select Printer</h4>
					<div class="row">
						<?php if(!empty($printer)): ?>
							<div class="toggle">
								<?php $__currentLoopData = $printer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_printer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<input type="radio" name="printer" value="<?php echo e($single_printer->device_ip); ?>" id="<?php echo e($single_printer->device_id); ?>" />
									<label for="<?php echo e($single_printer->device_id); ?>"><?php echo e($single_printer->device_id); ?></label>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>	
		</div>


		<div class="col-sm-2">
			<div class="row">
				<div class="col-12">
					Select Numbers to print
				</div>
				
				<div id="donate" class="col-12">
					<div class="row no-gutters mx-auto">
						<?php for($i = 1; $i <21 ; $i++): ?>
							<div class="col-6 totalNum">
								<label class="">
									<input type="radio" name="totalbarcodetoprint" class="" value="<?php echo e($i); ?>"> <span><?php echo e($i); ?></span>
								</label>
							</div>
						<?php endfor; ?>
					</div>
				</div>
				


				<div class="col-12">
					<strong>Total Production</strong>
					<span><?php echo e(sprintf('%06d',$last_barcode)); ?></span>
				</div>

				<div class="col-12">

					<div id="pagecontent">
						000077777
					</div>
					<button class="btn btn-primary mt-2" id="printBrcode">Print</button>
					<button class="btn btn-danger mt-2 " id="resetAll" type="reset">Reset</button>
					<a href="javascript:window.print();">Print</a><button class="btn btn-danger mt-2 " onClick="window.print()" type="reset">PC Print</button>
					<script language='VBScript'>
Sub Print()
       OLECMDID_PRINT = 6
       OLECMDEXECOPT_DONTPROMPTUSER = 2
       OLECMDEXECOPT_PROMPTUSER = 1
       call WB.ExecWB(OLECMDID_PRINT, OLECMDEXECOPT_DONTPROMPTUSER,1)
End Sub
document.write "<object ID='WB' WIDTH=0 HEIGHT=0 CLASSID='CLSID:8856F961-340A-11D0-A96B-00C04FD705A2'></object>"
</script>


					<a href="#" id="reprintBarcode" data-toggle="modal" data-target="#exampleModalCenter" class="btn btn-danger mt-3">Reprint a barcode</a>
				</div>


			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Reprint</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="text" id="BarcodeToRePrint" name="BarcodeToRePrint" placeholder="Enter Barcode to print" class="form-control">
        <hr>

        <label>Or Select form here</label>
        <select name="avalibaleBarcodeToPrint" id="avalibaleBarcodeToPrint" class="form-control">
        	<option>Select one Barcode</option>
        </select>

        <strong>Select Printer</strong>

        
		<div class="row">
			<div class="col-12">
				<?php if(!empty($printer)): ?>
					<div class="toggle">
						<?php $__currentLoopData = $printer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_printer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input type="radio" name="printer" id="printer-<?php echo e($single_printer->device_id); ?>" value="<?php echo e($single_printer->device_ip); ?>" >
							<label for="printer-<?php echo e($single_printer->device_id); ?>"><?php echo e($single_printer->device_id); ?></label>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="sendReprintCommand">RePrint</button>
      </div>
    </div>
  </div>
</div>









<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/main.js')); ?>"></script>
<script type="text/javascript">
	$(function(){
		//Date picker
	    $('#datepicker').datepicker({
	      autoclose: true,
	      format:'yyyy-mm-dd'
	    })

	    // console.log($("#datepicker").val());

		function Barcode(){
			var barcodeString = '';
			var last_num    = <?php echo e(11111+1); ?>;
			var grade       = (typeof($('input[name=grade]:checked').val()) !="undefined") ? $('input[name=grade]:checked').val() : '';
			var total_print = $('input[name=totalbarcodetoprint]:checked').val();
			var printer    = $('input[name=printer]:checked').val();
			var packer     = (typeof($('input[name=packer]:checked').val()) !="undefined") ? $('input[name=packer]:checked').val() : '';
			var watcher    = (typeof($('input[name=watcher]:checked').val()) !="undefined") ? $('input[name=watcher]:checked').val() : '';
			var machine    = $('#machineNUmber').text();
			var shift      = $('#shift').text();
			//console.log(machine);

			barcodeString = last_num+getdate()+shift+grade+machine+'_A'+watcher.replace('.','')+packer.replace('.','');
			// $('#barcodeString').html(barcodeString);
		}

		function getdate() {
			var d = new Date();
			var day = d.getDate();
			var month = d.getMonth();
			var year = d.getFullYear().toString().substr(-2);
			//console.log(year,month,day);
			return year+month+day;
		}

		function checkIfallChecked(){
		    if ( $('input:radio:checked').size() == 5 )    
		        return true;
		    return false;
		}

		function checkIfmodalallChecked(){
		    if ( $('.modal-body input:radio:checked').size() == 1 )    
		        return true;
		    return false;
		}

		$('input[name=grade]').on('change',function() {
			Barcode();
			//console.log($('input[name=grade]:checked').val());
		});

		$('input[name=totalbarcodetoprint]').on('change',function() {
			Barcode();
			//console.log($('input[name=totalbarcodetoprint]:checked').val());
		});

		$('input[name=packer]').on('change',function() {
			Barcode();
			//console.log($('input[name=packer]:checked').val());
		});

		$('input[name=watcher]').on('change',function() {
			Barcode();
			//console.log($('input[name=watcher]:checked').val());
		});

		$('#printBrcode').on('click',function(){
			//console.log(checkIfallChecked());
			if(checkIfallChecked()){

				var _token  = $('meta[name="csrf-token"]').attr('content');
				var grade    = (typeof($('input[name=grade]:checked').val()) !="undefined") ? $('input[name=grade]:checked').val() : '';
				var total_print = $('input[name=totalbarcodetoprint]:checked').val();
				var printer    = $('input[name=printer]:checked').val();
				var packer   = (typeof($('input[name=packer]:checked').val()) !="undefined") ? $('input[name=packer]:checked').val() : '';
				var watcher  = (typeof($('input[name=watcher]:checked').val()) !="undefined") ? $('input[name=watcher]:checked').val() : '';
				var machine  = $('#machineNUmber').text();
				var shift    = $('#shift').text();
				var production_date    = $('#datepicker').val();

				// console.log(_token,grade,total_print,printer,packer,watcher,machine,shift);
				var string = `watcher: ${watcher} || packer: ${packer} || grade: ${grade} || printer: ${printer} || total: ${total_print}`;



				swal({
				  title: "Are you sure !!",
    		  	  text: string,
				  type: "info",
				  showCancelButton: true,
				  closeOnConfirm: false,
				  showLoaderOnConfirm: true
				},

				function(isConfirm){
				  if (isConfirm){
				    
				    $.ajax({
				    	url: '<?php echo e(route('generateBarcode')); ?>',
				    	type: 'POST',
				    	dataType: 'json',
				    	data: {
				    		grade: grade,
				    		total_print: total_print,
				    		printer: printer,
				    		packer: packer,
				    		watcher: watcher,
				    		machine: machine,
				    		shift: shift,
				    		production_date: production_date,
				    		_token: _token,

				    	},
				    	success: function(data){
				    		console.log(data.bar);
							var d = data.bar.length;
							var i = 0;
							for (i = 0; i<=d; i++){
								if (i === d) {
									break;
								}
								setTimeout(function(i) {

								//console.log(i);
								// string to hex barcode
								var str=data.bar[i].barcode;
								var results = "";
								for (var j=0; j<str.length; j++) {
									hex = str.charCodeAt(j).toString(16);
									results += (hex).slice(-4);

								}
								//console.log(results);
								// string to hex batch
								var strs=data.bar[i].batch_no;
								var result_batch = "";
								for (var k=0; k<strs.length; k++) {
									hex = strs.charCodeAt(k).toString(16);
									result_batch += (hex).slice(-4);
								}
								console.log(results);
								var link ='1b411b50531b574b3278323230336470691b25321b48303535391b5630303136311b5031321b5030341b52444240302c3031342c3032342c'+result_batch+'1b25321b48303536391b5630303133301b42473031303838'+results+'1b25321b48303535391b5630303032351b5030321b52444240302c3031342c3032342c'+results+'1b51311b5a03';
								//$link = '1b411b50531b574b3278323230336470691b25321b48303535391b5630303136311b5031321b5030341b52444140302c3031342c3032342c3131323334354530333030303030301b25321b48303536391b5630303133301b424730323038383130414243373839373839373839371b25321b48303535391b5630303032351b5030321b52444140302c3031342c3032342c303132333435453033303030303030343741424344454647481b51311b5a03';
								var linkUrl = 'http://localhost:8080/Printer/SendRawData?__encoding=hex&__send_data='+link+'';

								// var delayInMilliseconds = 500; //0.5 second
								// setTimeout(function() {
									const Http = new XMLHttpRequest();
									const url=linkUrl;
									Http.open("GET", url);
									Http.send();
									Http.onreadystatechange=(e)=>{
										console.log(Http.responseText);
									}

								// }, delayInMilliseconds);

								}, i * 200, i);
							}

							var delayInMilliseconds = d * 1000; //2 second
							setTimeout(function() {
								// pdf print
								var route = "<?php echo e(route('allmachine')); ?>";
								var pdf = "/" + data.pdf;
								//window.location.href = route+pdf;
								// pdf end


								window.location.href = route+pdf;
								swal("Done!", "Barcode Printed Successfully", "success");
							}, delayInMilliseconds);
				    		// window.open(
				    		//   route+pdf,
				    		//   '_blank' // <- This is what makes it open in a new window.
				    		// );
				    		 //location.reload();


				    	},
				    	error: function (xhr, ajaxOptions, thrownError) {
				    		console.log(thrownError);
	    	                swal("Error!", "There was an error", "error");
	    	            }
				    });
				  } else {
				    swal("Cancelled", "Cancelled suucessfuly :)", "error");
				  }
				});

			}else{
				swal("Please select all the fields");
				//alert('Please select all the fields');
			}
		});

		//Refresh the $.browser
		window.addEventListener( "pageshow", function ( event ) {
		  var historyTraversal = event.persisted || 
                 ( typeof window.performance != "undefined" && 
                      window.performance.navigation.type === 2 );
		  if ( historyTraversal ) {
		    // Handle page restore.
		    window.location.reload();
		  }
		});



		$("#resetAll").on('click',function(){
			$('input').prop('checked', false);
			Barcode();
			$('#barcodeString').html('');
		});

		function reprintBarcode() {
			var machine    = $('#machineNUmber').text();
			var shift      = $('#shift').text();
			var _token  = $('meta[name="csrf-token"]').attr('content');

			$.ajax({
				url: '<?php echo e(route('getCurrentBarcodedata')); ?>',
				type: 'POST',
				dataType: 'JSON',
		    	data: {
		    		machine: machine,
		    		shift: shift,
		    		_token: _token,

		    	},
		    	success: function(data){
		    		// console.log(data);

		    		var barcode = `<option value="">Select Barcode</option>`;
			          $.each(data, function(index, data) {
			             barcode += `<option value='${data.barcode}'>${data.barcode}</option>`;
			          });
			         // console.log(barcode);
			          $('#avalibaleBarcodeToPrint').html(barcode);
		    		
		    	},
		    	error: function (xhr, ajaxOptions, thrownError) {
		    		console.log(thrownError);
	                //swal("Error!", "There was an error", "error");
	            }
			});
			
		}

		$("#reprintBarcode").on('click',function(){
			reprintBarcode();
		});

		$("#avalibaleBarcodeToPrint").change(function() {
			//console.log($("#avalibaleBarcodeToPrint").val());
			$("#BarcodeToRePrint").val($("#avalibaleBarcodeToPrint").val());
		});


		$('#sendReprintCommand').on('click',function(){
			//console.log(checkIfallChecked());
			if(checkIfmodalallChecked()){

				swal({
				  title: "Are you sure !!",
				  type: "info",
				  showCancelButton: true,
				  closeOnConfirm: false,
				  showLoaderOnConfirm: true
				},

				function(isConfirm){
				  if (isConfirm){
				    var _token  = $('meta[name="csrf-token"]').attr('content');
				    var printer    = $('.modal-body input[name=printer]:checked').val();
				    var barcode  = $("#BarcodeToRePrint").val();
				    var machine  = $('#machineNUmber').text();

				    $.ajax({
				    	url: '<?php echo e(route('requestToReprintBarcode')); ?>',
				    	type: 'POST',
				    	dataType: 'json',
				    	data: {
				    		barcode: barcode,
				    		printer: printer,
				    		machine: machine,
				    		_token: _token
				    	},
				    	success: function(data){
				    		// console.log(data);
				    		swal("Done!", data.msg, "success");
				    		var route = "<?php echo e(route('pdfstream')); ?>";
				    		var pdf   = "/"+data.pdf;
				    		window.location.href = route+pdf;
				    		// location.reload();
				    		
				    	},
				    	error: function (xhr, ajaxOptions, thrownError) {
				    		console.log(thrownError);
				    		swal("Error!", "There was an error", "error");
	    	            }
				    });
				  } else {
				    swal("Cancelled", "Cancelled suucessfuly :)", "error");
				  }
				});

			}else{
				swal("Please select a printer");
				//alert('Please select all the fields');
			}
		});


		

		

		//checkIfallChecked();

	});
</script>
<script>
	 const app = new Vue({
	    el: '#SingleMachine',
	    data: {
	    	barcode :{},
	    	shift: '',
	    	machine: '<?php echo e($machine->number); ?>',
	    	item: '',
	    	itemPlaceHolde: 'No Item Assigned',
	    	shiftPlaceHolde: 'No Shift Assigned',
	    	shift: '',
	    	watchers:{},
	    	packers:{},
	    	workers:{},
	    },

	    mounted(){
	    	this.getSnannedItem();
	    	// this.listen();

	    },

	    methods: {
	    	getSnannedItem(){
	    		axios.get('<?php echo e(route('getDailyShiftDetailsByMachine',$machine->number)); ?>')
	    		.then((res) => {
	    			// console.log(res.data);
	    			this.updateData(res.data);

	    			// var dummy = setInterval(this.getSnannedItem(),5000);
	    			// clearInterval(dummy);
	    		})
	    		.catch((err) =>{
	    			console.log(err);
	    		})
	    	},

	    	listen(){
	    		// Echo.channel('machine.'+this.machine)
	    		// 	.listen('NewWorkerAdded',(data)=>{
	    		// 		//console.log(data);
	    		// 		this.getSnannedItem();
	    		// 	})
	    	},
	    	updateData(data){
	    		this.barcode = data;
	    		this.setMachineDetails(data);
	    		if(data.workers.length){
		    		this.SetWorkers(data.workers);
		    	}
	    	},

	    	SetWorkers(workers){
	    		this.workers = workers;
	    		// this.setPackers(workers);
	    		// console.log(workers);
	    	},
	    	setMachineDetails(data){
	    		this.shift = data.shift;
	    		this.item = data.item;
	    		this.shift = data.shift;
	    	}

	    	

	    	
	    }
	});
</script>


</body>
</html>	
<?php echo $__env->make('includes.machine_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Daily Shift</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/sweetalert.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_end/css/style.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>

<?php echo $__env->make('includes.buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container pt-3 h-100">
	<div class="row">
		<div class="col-12">
			<strong>Ref No: <?php echo e($datas[0]->customer_ref_no); ?></strong>
		</div>
		<div class="col-6">
			
			<form method="POST" action="<?php echo e(route('placeorder')); ?>">
				<?php echo csrf_field(); ?>
			  <div class="form-group">
			    <label for="CustomerName">Customer Name</label>
			    <input type="text" class="form-control" id="CustomerName" name="name" required="" placeholder="Enter customer name">
			  </div>

			  <div class="form-group">
			    <label for="SalesOrder">Sales Order</label>
			    <input type="text" class="form-control" id="SalesOrder" name="sales_order" required="" placeholder="Enter SalesOrder">
			  </div>
			  
			  <div class="form-group">
			    <label for="transport_no">transport_no</label>
			    <input type="text" class="form-control" id="transport_no" name="transport_no" required="" placeholder="Enter transport_no">
			  </div>

			  <div class="form-group">
			    <label for="reference_no">reference_no</label>
			    <input type="text" class="form-control" id="reference_no" name="reference_no" required="" readonly="" value="<?php echo e($datas[0]->customer_ref_no); ?>" placeholder="Enter reference_no">
			  </div>

			  <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_barcode_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<input type="hidden" name="barcodes[]" value="<?php echo e($single_barcode_data->getbarcode->id); ?>" readonly="">
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			  <button type="submit" class="btn btn-primary">Submit</button>
			</form>
			
		</div>

		<div class="col-6">
			<p>Items <strong><?php echo e(count($datas)); ?></strong></p>
			<ul class="list-group">
			
				<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<li class="list-group-item"><?php echo e($data->barcode); ?> (<?php echo e($data->item[0]->item_name); ?>)</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</ul>
		</div>
	</div>
</div>











<script type="text/javascript" src="<?php echo e(asset('front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/sweetalert.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front_end/js/main.js')); ?>"></script>
<script type="text/javascript">
	$(function(){



	});
</script>
</body>
</html>	
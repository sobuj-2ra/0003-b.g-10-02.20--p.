<!DOCTYPE html>
<html>
<head>
	<title>ALl Machine</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/fontawesome.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/style.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
<?php echo $__env->make('includes.buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container pt-3 h-100">
	<div class="row d-flex align-items-center text-center justify-content-center h-100">
		<?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e(route('singlemachine',$single_machine->number)); ?>" class="col-3 pt-5 pb-5 bg-dark text-white d-block mr-1"><?php echo e($single_machine->name); ?>(<?php echo e($single_machine->number); ?>)</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>



<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/main.js')); ?>"></script>
</body>
</html>	
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$path = storage_path('app/public/pdfs/'.$link.'.pdf');
		$data = file_get_contents($path);
			header("Content-Type: application/force-download");
          header("Content-type: application/octet-stream");
          header("Content-disposition: inline;filename=".$link.".pdf");

          echo $data;
	?>

</body>
</html>
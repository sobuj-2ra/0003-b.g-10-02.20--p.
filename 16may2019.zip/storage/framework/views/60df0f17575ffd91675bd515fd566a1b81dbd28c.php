<span class="floating-btn">
	<a href="<?php echo e(route('index')); ?>" class="btn btn-info">Home</a>
	<a href="<?php echo e(url()->previous()); ?>" class="btn btn-info">Back</a>
	<?php if(Auth::check()): ?>
		<a href="<?php echo e(route('logout')); ?>" class="btn btn-danger" onclick="event.preventDefault();
		                 document.getElementById('logout-form').submit();">Logout</a>

		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
		    <?php echo csrf_field(); ?>
		</form>
		<?php $__env->startSection('single_machine_edit'); ?>
			<?php echo $__env->yieldSection(); ?>
	<?php endif; ?>
</span>
<?php $__env->startSection('title','Add Machine'); ?>

<?php $__env->startSection('extra_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="display: inline-block;">
        Add Machine
      </h1>
      <a href="<?php echo e(route('machines.index')); ?>" class="btn btn-success pull-right ">List</a>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- general form elements -->
      <div class="box box-success">
        <div class="box-header with-border">
          <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div id="form_output"></div>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" id="ajax_form" action="<?php echo e(route('machines.store')); ?>" method="POST" enctype="multipart/form-data">
          <div class="box-body">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
              <label for="name">Machine Name</label>
              <input type="text" name="name" class="form-control" id="name" placeholder="Enter machine Name" value="<?php echo e(old('name')); ?>" required="">
            </div>

            <div class="form-group">
              <label for="number">Machine number</label>
              <input type="text" name="number" class="form-control" id="number" placeholder="Enter machine number" value="<?php echo e(old('number')); ?>" required="">
              <span id="deviceError" class="bg-danger"></span>
            </div>

          </div>
          <!-- /.box-body -->

          <div class="box-footer">
            <button type="submit" id="add_data" class="btn btn-success">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.box -->

      

    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>
<!-- InputMask -->
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.numeric.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>

<script type="text/javascript">
	$(function(){

    $('#number').on('keyup',function(){
      var number = $('#number').val();
      var _token = $('input[name="_token"]').val();

      //console.log(number,_token);
      $.ajax({
        url: "<?php echo e(route('checkMachineId')); ?>",
        type: 'POST',
        dataType: 'json',
        data: {number:number,_token:_token},
        success: function(data){
          console.log(data);
          $('#deviceError').html(data.message);
        }
      });
    });

    
    
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title','User add'); ?>

<?php $__env->startSection('extra_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/plugins/iCheck/all.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="display: inline-block;">
        Add Employee
      </h1>
      <a href="<?php echo e(route('users.index')); ?>" class="btn btn-success pull-right ">List</a>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- general form elements -->
      <div class="box box-success">
        <div class="box-header with-border">
          <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div id="form_output"></div>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" id="ajax_form" action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data">
          <div class="box-body">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
              <label for="admin_name">Employee Name</label>
              <input type="text" name="name" class="form-control" id="admin_name" placeholder="Enter Employee Name" value="<?php echo e(old('name')); ?>" required="">
            </div>

            <div class="form-group">
              <label for="employee_id">Employee Id</label>
              <input type="text" data-inputmask="'mask': '999.999'" data-mask name="employee_id" class="form-control" id="employee_id" placeholder="Enter Employee id" value="<?php echo e(old('employee_id')); ?>" required="">
              <span id="employeeError" class="bg-danger"></span>
            </div>

            <div class="form-group">
              <label for="password">password</label>
              <input type="text" id="password" name="password" class="form-control" placeholder="password" value="<?php echo e(old('password')); ?>">
            </div>

            <div class="form-group">
              <label for="group">Group</label>
              <select name="group" class="form-control" required="">
              	<option value="">Select</option>
              	<option value="watcher">watcher</option>
              	<option value="packer">packer</option>
              	<option value="manager">manager</option>
              </select>
            </div>

            <div class="form-group">
              <label for="">Assign Page</label> <br>
              <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label><input type="checkbox" name="permission[]" class="flat-red" value="<?php echo e($permission->id); ?>">  <?php echo e($permission->page_name); ?>  </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="form-group">
              <label for="image">image</label>
              <input type="file" id="image" name="image" class="form-control" onchange="document.getElementById('output').src = window.URL.createObjectURL(this.files[0])" accept="image/*" required="">
              <img id="output" height="150px" width="auto" /><br>
            </div>

          </div>
          <!-- /.box-body -->

          <div class="box-footer">
            <button type="submit" id="add_data" class="btn btn-success">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.box -->

      

    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>
<!-- InputMask -->
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.numeric.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin_asset/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
  <script src="<?php echo e(asset('public/admin_asset/plugins/iCheck/icheck.min.js')); ?>"></script>
  <script type="text/javascript">
    $(function () {
      //Flat red color scheme for iCheck
         $('input[type="checkbox"].flat-red').iCheck({
           checkboxClass: 'icheckbox_flat-green',
           radioClass   : 'iradio_flat-green'
         })
    })
  </script>

<script type="text/javascript">
	$(function(){
		//Datemask dd/mm/yyyy
		$('#datemask').inputmask('dd-mm-yyyy', { 'placeholder': 'dd-mm-yyyy' });
		$('#employee_id,#phone').inputmask();

    $('#employee_id').on('blur',function(){
      var employee_id = $('#employee_id').val();
      var _token = $('input[name="_token"]').val();

      //console.log(employee_id,_token);
      $.ajax({
        url: "<?php echo e(route('employeeIdChcek')); ?>",
        type: 'POST',
        dataType: 'json',
        data: {employee_id:employee_id,_token:_token},
        success: function(data){
          //console.log(data);
          $('#employeeError').html(data.message);
        }
      });
    });

    $('#email').on('blur paste',function(){
      var email = $('#email').val();
      var _token = $('input[name="_token"]').val();

      //console.log(employee_id,_token);
      $.ajax({
        url: "<?php echo e(route('empolyeeEmailCheck')); ?>",
        type: 'POST',
        dataType: 'json',
        data: {email:email,_token:_token},
        success: function(data){
          //console.log(data);
          $('#emailError').html(data.message);
        }
      });
    });

    $('#phone').on('blur paste',function(){
      var phone = $('#phone').val();
      var _token = $('input[name="_token"]').val();

      //console.log(employee_id,_token);
      $.ajax({
        url: "<?php echo e(route('employeePhnCheck')); ?>",
        type: 'POST',
        dataType: 'json',
        data: {phone:phone,_token:_token},
        success: function(data){
          //console.log(data);
          $('#phnError').html(data.message);
        }
      });
    });



    
    
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
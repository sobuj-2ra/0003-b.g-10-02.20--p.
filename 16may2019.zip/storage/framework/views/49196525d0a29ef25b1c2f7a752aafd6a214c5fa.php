<!DOCTYPE html>
<html>
<head>
    <title>BGWP</title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/front_end/css/style.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>

<div class="bg-grey h-100">
    <div class="container d-flex h-100">
        <div class="row h-100 text-center justify-content-center align-items-center">
            <div class="col-12">
                <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="row text-center">
                    <div class="col-4 mb-3">
                        <a href="<?php echo e(route('dailyshift')); ?>" class="">
                            <div class="card text-white border-danger bg-danger p-1 text-center">
                                <div class="card-body">
                                    <h2 class="card-title">Shifts</h2>
                                    <p class="card-text">Click to go</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-4 mb-3">
                        <a href="<?php echo e(route('allmachine')); ?>" class="">
                            <div class="card text-white border-danger bg-danger p-1 text-center">
                                <div class="card-body">
                                    <h2 class="card-title">Machines</h2>
                                    <p class="card-text">Click to view all machine</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-4 mb-3">
                        <a href="<?php echo e(route('stockouts')); ?>" class="">
                            <div class="card text-white border-danger bg-danger p-1 text-center">
                                <div class="card-body">
                                    <h2 class="card-title">Delivery Section</h2>
                                    <p class="card-text">Click to go</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-4 mb-3">
                        <a href="<?php echo e(route('dashboard')); ?>" class="">
                            <div class="card text-white border-danger bg-danger p-1 text-center">
                                <div class="card-body">
                                    <h2 class="card-title">Admin Section</h2>
                                    <p class="card-text">Click to go</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-4 mb-3">
                        <a href="<?php echo e(route('scanners')); ?>" class="">
                            <div class="card text-white border-danger bg-danger p-1 text-center">
                                <div class="card-body">
                                    <h2 class="card-title">Hand Held Section</h2>
                                    <p class="card-text">Click to go</p>
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
            
        </div>
    </div>
</div>




<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/front_end/js/main.js')); ?>"></script>
</body>
</html> 